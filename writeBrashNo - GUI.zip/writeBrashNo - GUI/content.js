function runBrashReplacement() {
  const title = document.title.trim();
  const lowerTitle = title.toLowerCase();

  
  if (!lowerTitle.includes('leave') && !lowerTitle.includes('report') && !lowerTitle.includes('সিসি') && !lowerTitle.includes('সাক্ষী')) {
    console.log("► [BP AutoMapper] Ignored page title: " + title);
    return; 
  }

  
  chrome.storage.local.get({ bpMap: {} }, (data) => {
    const bpMap = data.bpMap;
    if (Object.keys(bpMap).length === 0) return;

    
    const blocks = document.querySelectorAll('tr, td, p, div, li');

    blocks.forEach(block => {
      
      if (block.innerText && block.innerText.includes("বর্তমান")) return;

      
      let htmlContent = block.innerHTML;
      if (!htmlContent) return;

      let structuralChangesMade = false;

      for (let bpID in bpMap) {
        
        if (htmlContent.includes(bpID)) {
          const brashNumber = bpMap[bpID];
          
          const designatoryRanks = [
            "পদবী : কনস্টেবল", 
            "পদবী : নায়েক", 
            "পদবী : এএসআই (সশস্ত্র)", 
            "পদবী : এটিএসআই"
          ];

          designatoryRanks.forEach(rank => {
            
            if (htmlContent.includes(rank) && !htmlContent.includes(`${rank}/${brashNumber}`)) {
              
              htmlContent = htmlContent.split(rank).join(`${rank}/${brashNumber}`);
              structuralChangesMade = true;
            }
          });
        }
      }

      if (structuralChangesMade) {
        block.innerHTML = htmlContent;
      }
    });
  });
}


chrome.runtime.onMessage.addListener((request) => {
  if (request.action === "rerun_scan") {
    runBrashReplacement();
  }
});


if (document.readyState === 'complete' || document.readyState === 'interactive') {
  runBrashReplacement();
  setTimeout(runBrashReplacement, 1000);
  setTimeout(runBrashReplacement, 2500);
} else {
  window.addEventListener('DOMContentLoaded', () => {
    runBrashReplacement();
    setTimeout(runBrashReplacement, 1500);
  });
}