document.addEventListener('DOMContentLoaded', () => {
  const bpInput = document.getElementById('bp-id');
  const brashInput = document.getElementById('brash-no');
  const bpError = document.getElementById('bp-error');
  const brashError = document.getElementById('brash-error');
  const saveBtn = document.getElementById('save-btn');
  const listContainer = document.getElementById('mapping-list');

  
  function loadItems() {
    chrome.storage.local.get({ bpMap: {} }, (data) => {
      const bpMap = data.bpMap;
      listContainer.innerHTML = '';
      
      if (Object.keys(bpMap).length === 0) {
        listContainer.innerHTML = '<tr><td colspan="3" style="color:#888; font-style:italic; padding:6px;">No records saved.</td></tr>';
        return;
      }

      for (let bpID in bpMap) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${bpID}</td>
          <td><strong>${bpMap[bpID]}</strong></td>
          <td style="text-align: right;">
            <button class="action-btn edit-btn" data-id="${bpID}" data-brash="${bpMap[bpID]}" title="Edit entry for ${bpID}">Edit</button>
            <button class="action-btn del-btn" data-id="${bpID}" title="Delete entry for ${bpID}">X</button>
          </td>
        `;
        listContainer.appendChild(tr);
      }

     
      document.querySelectorAll('.del-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          
          const button = e.currentTarget || e.target;
          const id = button.getAttribute('data-id');
          
          if (!id) return; 

          if (confirm(`Are you sure you want to delete ${id}?`)) {
            chrome.storage.local.get({ bpMap: {} }, (data) => {
              delete data.bpMap[id];
              chrome.storage.local.set({ bpMap: data.bpMap }, () => {
                loadItems();
                notifyPageDataChanged();
              });
            });
          }
        });
      });

      
      document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          clearErrors();
          const button = e.currentTarget || e.target;
          bpInput.value = button.getAttribute('data-id');
          brashInput.value = button.getAttribute('data-brash');
        });
      });
    });
  }

  function clearErrors() {
    bpError.innerText = '';
    brashError.innerText = '';
    bpInput.classList.remove('invalid');
    brashInput.classList.remove('invalid');
  }

  saveBtn.addEventListener('click', () => {
    clearErrors();

    const id = bpInput.value.trim();
    const brash = brashInput.value.trim();
    let hasError = false;

    if (!id) {
      bpError.innerText = 'Required field.';
      bpInput.classList.add('invalid');
      hasError = true;
    } else if (/\D/.test(id)) {
      bpError.innerText = 'Numbers only.';
      bpInput.classList.add('invalid');
      hasError = true;
    } else if (id.length !== 10) {
      bpError.innerText = `Must be 10 digits (Got ${id.length}).`;
      bpInput.classList.add('invalid');
      hasError = true;
    }

    if (!brash) {
      brashError.innerText = 'Required field.';
      brashInput.classList.add('invalid');
      hasError = true;
    } else if (/\D/.test(brash)) {
      brashError.innerText = 'Numbers only.';
      brashInput.classList.add('invalid');
      hasError = true;
    }

    if (hasError) return;

    
    chrome.storage.local.get({ bpMap: {} }, (data) => {
      data.bpMap[id] = brash;
      chrome.storage.local.set({ bpMap: data.bpMap }, () => {
        bpInput.value = '';
        brashInput.value = '';
        loadItems();
        notifyPageDataChanged();
      });
    });
  });

  bpInput.addEventListener('input', clearErrors);
  brashInput.addEventListener('input', clearErrors);

  async function notifyPageDataChanged() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action: "rerun_scan" }).catch(() => {});
    }
  }

  loadItems();
});